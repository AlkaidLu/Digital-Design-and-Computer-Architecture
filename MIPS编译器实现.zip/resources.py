register = {'$a0': '00100', '$t5': '01101', '$gp': '11100',
            '$0' : '00000', '$s3': '10011', '$s2': '10010',
            '$s1': '10001', '$s0': '10000', '$s7': '10111',
            '$s6': '10110', '$s5': '10101', '$s4': '10100',
            '$ra': '11111', '$fp': '11110', '$v0': '00010',
            '$v1': '00011', '$a3': '00111', '$a2': '00110',
            '$a1': '00101', '$t8': '11000', '$t9': '11001',
            '$t6': '01110', '$t7': '01111', '$t4': '01100',
            '$sp': '11101', '$t2': '01010', '$t3': '01011',
            '$t0': '01000', '$t1': '01001', '$at': '00001'}
 
reverse_register = {0:'$zero',1:'$at',2:'$v0',3:'$v1',4:'$a0',5:'$a1',6:'$a2',7:'$a3',8:'$t0',9:'$t1',10:'$t2',
            11:'$t3',12:'$t4',13:'$t5',14:'$t6',15:'$t7',16:'$s0',17:'$s1',18:'$s2',19:'$s3',
            20:'$s4',21:'$s5',22:'$s6',23:'$s7',24:'$t8',25:'$t9',26:'$k0',27:'$k1',28:'$gp',29:'$sp',30:'$fp',31:'$ra'}
            
IS = {
       # 实现成类
       # opcode IS
       'bltz':{'type': 'I', 'opcode': 1, 'form': ['rs', 'label']},
       'j'   :{'type': 'I', 'opcode': 2, 'form': ['label']},
       'jal' :{'type': 'I', 'opcode': 3, 'form': ['label']},
       'beq' :{'type': 'I', 'opcode': 4, 'form': ['rs', 'rt', 'label']},
       'bne' :{'type': 'I', 'opcode': 5, 'form': ['rs', 'rt', 'label']},
       'blez':{'type': 'I', 'opcode': 6, 'form': ['rs', 'label']},
       'bgtz':{},
       'addi':{'type': 'I', 'opcode': 8, 'form': ['rt', 'rs', 'imm']},
       'addiu':{},
       'slti':{'type': 'I', 'opcode': 10, 'form': ['rt', 'rs', 'imm']},
       'sltiu':{},
       'andi':{'type': 'I', 'opcode': 12, 'form': ['rt', 'rs', 'imm']},
       'ori' :{'type': 'I', 'opcode': 13, 'form': ['rt', 'rs', 'imm']},
       'xori':{'type': 'I', 'opcode': 14, 'form': ['rt', 'rs', 'imm']},
       'lui' :{'type': 'I', 'opcode': 15, 'form': ['rt', 'imm']},
       'lb'  :{'type': 'I', 'opcode': 32, 'form': ['rt', 'imm', 'rs']},
       'lh'  :{'type': 'I', 'opcode': 33, 'form': ['rt', 'imm', 'rs']},
       'lw'  :{'type': 'I', 'opcode': 35, 'form': ['rt', 'imm', 'rs']},
       'sb'  :{'type': 'I', 'opcode': 40, 'form': ['rt', 'imm', 'rs']},
       'sh'  :{'type': 'I', 'opcode': 41, 'form': ['rt', 'imm', 'rs']},
       'sw'  :{'type': 'I', 'opcode': 43, 'form': ['rt', 'imm', 'rs']},
       # R IS
       
       'sll' :{'type': 'R', 'opcode': 0, 'func': 0, 'form': ['rd', 'rt', 'shamt']},
       'srl' :{'type': 'R', 'opcode': 0, 'func': 2, 'form': ['rd', 'rt', 'shamt']},
       'sra' :{'type': 'R', 'opcode': 0, 'func': 3, 'form': ['rd', 'rt', 'shamt']},
       'sllv':{'type': 'R', 'opcode': 0, 'func': 4, 'form': ['rd', 'rt', 'rs']},
       'srlv':{'type': 'R', 'opcode': 0, 'func': 6, 'form': ['rd', 'rt', 'rs']},
       'srav':{'type': 'R', 'opcode': 0, 'func': 7, 'form': ['rd', 'rt', 'rs']},
       'jr'  :{'type': 'R', 'opcode': 0, 'func': 8, 'form': ['rs']},
       'jalr':{'type': 'R', 'opcode': 0, 'func': 9, 'form': ['rs']},
       'mfhi':{'type': 'R', 'opcode': 0, 'func': 16, 'form': ['rs']},        
       'mthi':{'type': 'R', 'opcode': 0, 'func': 17, 'form': ['rs']}, 
       'mflo':{'type': 'R', 'opcode': 0, 'func': 18, 'form': ['rs']}, 
       'mtlo':{'type': 'R', 'opcode': 0, 'func': 19, 'form': ['rs']},
       'mult':{'type': 'R', 'opcode': 0, 'func': 24, 'form': ['rs']},    
       'add' :{'type': 'R', 'opcode': 0, 'func': 32, 'form': ['rd', 'rs', 'rt']},
       'sub' :{'type': 'R', 'opcode': 0, 'func': 34, 'form': ['rd', 'rs', 'rt']},
       'and' :{'type': 'R', 'opcode': 0, 'func': 36, 'form': ['rd', 'rs', 'rt']},
       'or'  :{'type': 'R', 'opcode': 0, 'func': 37, 'form': ['rd', 'rs', 'rt']},
       'xor' :{'type': 'R', 'opcode': 0, 'func': 38, 'form': ['rd', 'rs', 'rt']},
       'nor' :{'type': 'R', 'opcode': 0, 'func': 39, 'form': ['rd', 'rs', 'rt']},
       'slt' :{'type': 'R', 'opcode': 0, 'func': 42, 'form': ['rd', 'rs', 'rt']},
 
    
        
       }       
pseudoIS={           
       'nop' :{'type': 'P', 'instruction': 'addi $0, $0, 0'},             
       'li'  :{'type': 'P', 'instruction': ''},              
       'mv'  :{'type': 'P', 'instruction': ''},              
       'not' :{'type': 'P', 'instruction': ''},             
       'neg' :{'type': 'P', 'instruction': ''},     
}