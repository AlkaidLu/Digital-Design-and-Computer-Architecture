from resources import *
import re
 
def num2bin(num,length):
    if(num >= 0):
        temp = bin(num).replace('0b','')
        while(len(temp) < length):
            temp = '0' + temp
        return temp
    else:
        num = 2**length+num
        res = bin(num).replace('0b','')
        return res
# opRS
 
# def asm_bltz(param, line, symbol_table, address):
    # rs = regiser.get(param[0], 'error')
    # label= regiser.get(param[1], 'error')
    
    
    # return IS['bltz']['opcode'] + rs
 
def asm_j(param, line, symbol_table, address):
    # result = IS['j']['opcode']
    place = symbol_table.get(param[0], 'error')
    # print('\n')
    # print(place)
    # print('\n')
    if(place=='error'):
        raise Exception('Line %d : No such symbol.' % line)
    return num2bin(IS['j']['opcode'],6) + num2bin(int(place/4), 26)
 
def asm_jal(param, line, symbol_table, address):
    place = symbol_table.get(param[0], 'error')
    # print('\n')
    # print(place)
    # print('\n')
    if(place=='error'):
        raise Exception('Line %d : No such symbol.' % line)
    return num2bin(IS['jal']['opcode'], 6) + num2bin(int(place/4), 26)
    
def asm_jalr(param, line, symbol_table, address):
    rs = register.get(param[0], 'error')
    if rs =='error' :
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['jalr']['opcode'], 6) + rs + '000001111100000' + num2bin(IS['jalr']['func'], 6)
 
def asm_beq(param, line, symbol_table, address):
    rs = register.get(param[0], 'error')
    rt = register.get(param[1], 'error')
    place = symbol_table.get(param[2], 'error')
    diff = place - address - 4
    if(place=='error'):
        raise Exception('Line %d : No such symbol.' % line)
    return num2bin(IS['beq']['opcode'],6) + rs + rt + num2bin(int(diff/4), 16)
 
def asm_bne(param, line, symbol_table, address):
    rs = register.get(param[0], 'error')
    rt = register.get(param[1], 'error')
    place = symbol_table.get(param[2], 'error')
    if(place == 'error'):
        raise Exception('Line %d : No such symbol.' % line)
    return num2bin(IS['bne']['opcode'],6) + num2bin(int(place/4), 26)
 
    
def blez(param, line, symbol_table, address):
    rs = register.get(param[0], 'error')
    place = symbol_table.get(param[1], 'error')
    if(place == 'error'):
        raise Exception('Line %d : No such symbol.' % line)
    return num2bin(IS['blez']['opcode'], 6) + rs + '000000000000000' + num2bin(IS['blez']['opcode', 6])
 
def blzt(param, line, symbol_table, address):
    rs = register.get(param[0], 'error')
    place = symbol_table.get(param[1], 'error')
    if(place == 'error'):
        raise Exception('Line %d : No such symbol.' % line)
    return num2bin(IS['blzt']['opcode'], 6) + rs + '000000000000000' + num2bin(IS['blzt']['opcode', 6])
 
def asm_addi(param, line, symbol_table, address):
    rt = register.get(param[0], 'error')
    rs = register.get(param[1], 'error')
    imm = param[2]
    if rs =='error' or rt == 'error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['addi']['opcode'], 6) + rs + rt  + num2bin(int(imm), 16)
 
 
def asm_slti(param, line, symbol_table, address):
    rt = register.get(param[0], 'error')
    rs = register.get(param[1], 'error')
    imm = param[2]
    if rs =='error' or rt == 'error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['slti']['opcode'], 6) + rs + rt  + num2bin(int(imm), 16)
 
 
def asm_andi(param, line, symbol_table, address):
    rt = register.get(param[0], 'error')
    rs = register.get(param[1], 'error')
    imm = param[2]
    if rs =='error' or rt == 'error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['andi']['opcode'], 6) + rs + rt  + num2bin(int(imm), 16)
 
 
 
def asm_ori(param, line, symbol_table, address):
    rt = register.get(param[0], 'error')
    rs = register.get(param[1], 'error')
    imm = param[2]
    if rs =='error' or rt == 'error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['ori']['opcode'], 6) + rs + rt  + num2bin(int(imm), 16)
 
 
 
def asm_xori(param, line, symbol_table, address):
    rt = register.get(param[0], 'error')
    rs = register.get(param[1], 'error')
    imm = param[2]
    if rs =='error' or rt == 'error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['xori']['opcode'], 6) + rs + rt  + num2bin(int(imm), 16)
 
 
 
def asm_lui(param, line, symbol_table, address):
    rt = register.get(param[0], 'error')
    imm = param[1]
    if rt =='error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['lui']['opcode'], 6) + '00000' + rt  + num2bin(int(imm), 16)
 
 
def asm_lb(param, line, symbol_table, address):
    rt = register.get(param[0], 'error')
    imm = param[1][0]
    rs = register.get(param[1][2:-1], 'error')
    if rs =='error' or rt == 'error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['lb']['opcode'], 6) + rs + rt  + num2bin(int(imm), 16)
 
 
def asm_lh(param, line, symbol_table, address):
    rt = register.get(param[0], 'error')
    imm = param[1][0]
    rs = register.get(param[1][2:-1], 'error')
    if rs =='error' or rt == 'error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['lh']['opcode'], 6) + rs + rt  + num2bin(int(imm), 16)
 
 
def asm_lw(param, line, symbol_table, address):
    rt = register.get(param[0], 'error')
    imm = param[1]
    rs = register.get(param[2], 'error')
 
    if rt == 'error' or rs == 'error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['lw']['opcode'], 6) + rs + rt  + num2bin(int(imm), 16)
 
 
def asm_sb(param, line, symbol_table, address):
    rt = register.get(param[0], 'error')
    imm = param[1][0]
    rs = register.get(param[1][2:-1], 'error')
    if rs =='error' or rt == 'error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['sb']['opcode'], 6) + rs + rt  + num2bin(int(imm), 16)
 
 
def asm_sh(param, line, symbol_table, address):
    rt = register.get(param[0], 'error')
    imm = param[1][0]
    rs = register.get(param[1][2:-1], 'error')
    if rs =='error' or rt == 'error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['sh']['opcode'], 6) + rs + rt  + num2bin(int(imm), 16)
 
 
def asm_sw(param, line, symbol_table, address):
    rt = register.get(param[0], 'error')
    imm = param[1]
    rs = register.get(param[2], 'error')
 
    if rt == 'error' or rs == 'error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['sw']['opcode'], 6) + rs + rt  + num2bin(int(imm), 16)
 
 
# RIS
 
def asm_sll(param, line, symbol_table, address):
    rd = register.get(param[0], 'error')
    rt = register.get(param[1], 'error')
    shamt = param[2]
    if rd =='error' or rt == 'error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['sll']['opcode'], 6) + '00000' + rt + rd + num2bin(int(shamt), 5) + num2bin(IS['sll']['func'], 6)
 
 
def asm_srl(param, line, symbol_table, address):
    rd = register.get(param[0], 'error')
    rt = register.get(param[1], 'error')
    shamt = param[2]
    if rd =='error' or rt == 'error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['srl']['opcode'], 6) + '00000' + rt + rd + num2bin(int(shamt), 5) + num2bin(IS['srl']['func'], 6)
 
 
 
def asm_sra(param, line, symbol_table, address):
    rd = register.get(param[0], 'error')
    rt = register.get(param[1], 'error')
    shamt = param[2]
    if rd =='error' or rt == 'error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['sra']['opcode'], 6) + '00000' + rt + rd + num2bin(int(shamt), 5) + num2bin(IS['sra']['func'], 6)
 
 
 
def asm_sllv(param, line, symbol_table, address):
    rd = register.get(param[0], 'error')
    rt = register.get(param[1], 'error')
    rs = register.get(param[2], 'error')
    if rd =='error' or rs == 'error' or rt =='error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['sllv']['opcode'],6) + rs + rt + rd + '00000' + num2bin(IS['sllv']['func'],6)
 
 
def asm_srlv(param, line, symbol_table, address):
    rd = register.get(param[0], 'error')
    rt = register.get(param[1], 'error')
    rs = register.get(param[2], 'error')
    if rd =='error' or rs == 'error' or rt =='error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['srlv']['opcode'],6) + rs + rt + rd + '00000' + num2bin(IS['srlv']['func'],6)
 
 
def asm_srav(param, line, symbol_table, address):
    rd = register.get(param[0], 'error')
    rt = register.get(param[1], 'error')
    rs = register.get(param[2], 'error')
    if rd =='error' or rs == 'error' or rt =='error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['srav']['opcode'],6) + rs + rt + rd + '00000' + num2bin(IS['srav']['func'],6)
 
 
def asm_jr(param, line, symbol_table, address):
    rs = register.get(param[0], 'error')
    if rs == 'error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['jr']['opcode'], 6) + rs + '000000000000000' + num2bin(IS['jr']['func'], 6)
 
 
 
def asm_add(param, line, symbol_table, address):
    rd = register.get(param[0], 'error')
    rs = register.get(param[1], 'error')
    rt = register.get(param[2], 'error')
    if rd =='error' or rs == 'error' or rt =='error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['add']['opcode'],6) + rs + rt + rd + '00000' + num2bin(IS['add']['func'],6)
 
def asm_sub(param, line, symbol_table, address):
    rd = register.get(param[0], 'error')
    rs = register.get(param[1], 'error')
    rt = register.get(param[2], 'error')
    if rd =='error' or rs == 'error' or rt =='error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['sub']['opcode'], 6) + rs + rt + rd + '00000' + num2bin(IS['sub']['func'], 6)
 
def asm_and(param, line, symbol_table, address):
    rd = register.get(param[0], 'error')
    rs = register.get(param[1], 'error')
    rt = register.get(param[2], 'error')
    if rd =='error' or rs == 'error' or rt =='error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['and']['opcode'], 6) + rs + rt + rd + '00000' + num2bin(IS['and']['func'], 6)
 
 
def asm_or(param, line, symbol_table, address):
    rd = register.get(param[0], 'error')
    rs = register.get(param[1], 'error')
    rt = register.get(param[2], 'error')
    if rd =='error' or rs == 'error' or rt =='error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['or']['opcode'], 6) + rs + rt + rd + '00000' + num2bin(IS['or']['func'], 6)
 
 
def asm_xor(param, line, symbol_table, address):
    rd = register.get(param[0], 'error')
    rs = register.get(param[1], 'error')
    rt = register.get(param[2], 'error')
    if rd =='error' or rs == 'error' or rt =='error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['xor']['opcode'], 6) + rs + rt + rd + '00000' + num2bin(IS['xor']['func'], 6)
 
def asm_nor(param, line, symbol_table, address):
    rd = register.get(param[0], 'error')
    rs = register.get(param[1], 'error')
    rt = register.get(param[2], 'error')
    if rd =='error' or rs == 'error' or rt =='error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['nor']['opcode'], 6) + rs + rt + rd + '00000' + num2bin(IS['nor']['func'], 6)
 
def asm_slt(param, line, symbol_table, address):
    rd = register.get(param[0], 'error')
    rs = register.get(param[1], 'error')
    rt = register.get(param[2], 'error')
    if rd =='error' or rs == 'error' or rt =='error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['slt']['opcode'], 6) + rs + rt + rd + '00000' + num2bin(IS['slt']['func'], 6)
 
 
 
#pseudoIS
def asm_nop(param, line, symbol_table, address):
    return '100010000100000000000000000000'
 
def asm_li(param, line, symbol_table, address):
    rt = register.get(param[0], 'error')
    imm = num2bin(int(param[1]), 32)
    imm_high = imm[0:15]
    imm_low = imm[16:31]
    if rt == 'error':
        raise Exception('Line %d : No such register.' % line)
    c1 = num2bin(IS['lui']['opcode'], 6) + '00000' + rt  + imm_high  
    c2 = num2bin(IS['ori']['opcode'], 6) + rt + rt + imm_low
    return c1 + '\n' + c2
 
def asm_mv(param, line, symbol_table, address):
    a = param[0]
    b = param[1]
    p = [a, b, 0]
    return asm_addi(p, line, symbol_table, address)
 
def asm_not(param, line, symbol_table, address):
    a = param[0]
    b = param[1]
    p = [a, b, -1]
    return asm_xori(p, line, symbol_table, address)
 
def asm_neg(param, line, symbol_table, address):
    rd = param[0]
    rs = '$0'
    rt = param[1]
    p = [rd, rs, rt]
    return asm_sub(p, line, symbol_table, address)
 
 
def asm_mfhi(param, line, symbol_table, address):
    rd = register.get(param[0], 'error')
    if rd =='error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['mfhi']['opcode'], 6) + '0000000000' + rd + '00000' + num2bin(IS['mfhi']['func'], 6)
     
def asm_mflo(param, line, symbol_table, address):
    rd = register.get(param[0], 'error')
    if rd =='error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['mflo']['opcode'], 6) + '0000000000' + rd + '00000' + num2bin(IS['mflo']['func'], 6)
 
def asm_mult(param, line, symbol_table, address):
    rs = register.get(param[0], 'error')
    rt = register.get(param[1], 'error')
    if rs =='error' or rt == 'error' :
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['mult']['opcode'], 6) + rs + rt + '0000000000' + num2bin(IS['mult']['func'], 6)
 
def asm_mthi(param, line, symbol_table, address):
    rs = register.get(param[0], 'error')
    if rs =='error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['mthi']['opcode'], 6) + rs + '0000000000' + '00000' + num2bin(IS['mthi']['func'], 6)
 
def asm_mtlo(param, line, symbol_table, address):
    rs = register.get(param[0], 'error')
    if rs =='error':
        raise Exception('Line %d : No such register.' % line)
    return num2bin(IS['mtlo']['opcode'], 6) + rs + '0000000000' + '00000' + num2bin(IS['mtlo']['func'], 6)
 
functions = {
 'add': asm_add,
 'addi': asm_addi,
 'and': asm_and,
 'andi': asm_andi,
 'sra':asm_sra,
 'srav':asm_srav,
 'beq': asm_beq,
 #'bltz': asm_bltz,
 'bne': asm_bne,
 
 'j': asm_j,
 'jal': asm_jal,
 'jalr': asm_jalr,
 'jr': asm_jr,
 
 'lb': asm_lb,
 'lui': asm_lui,
 'lw': asm_lw,
 
 'mfhi':asm_mfhi,
 'mflo':asm_mflo,
 'mthi': asm_mthi,
 'mtlo': asm_mtlo,
 #'mulo': asm_mulo,
 'mult': asm_mult,
 
 'nop': asm_nop,
 'nor': asm_nor,
 
 'or': asm_or,
 'ori': asm_ori,
 
 'sb': asm_sb,
 'sh': asm_sh,
 'sll': asm_sll,
 'sllv': asm_sllv,
 'slt': asm_slt,
 'slti': asm_slti,
 #'sltu': asm_sltu,
 'srl': asm_srl,
 'srlv': asm_srlv,
 'sub': asm_sub,
 'sw': asm_sw,
 
 'xor': asm_xor,
 'xori': asm_xori,
 # pseudo
 'nop' : asm_nop, 
 'li'  : asm_li,
 'mv'  : asm_mv,
 'not' : asm_not,
 'neg' : asm_neg
 }
 