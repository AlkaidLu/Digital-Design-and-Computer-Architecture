import re
from functions import *

#处理判断某行是否出错
###############################################
#错误指令测试，需要给出错误的行号，并指向错误之处
#合法性判断，应该检查下列事项：
# 1、是否是合法的操作码
# 2、操作数个数、类型是否正确
# 3、（立即数）操作数是否超出范围
# 4、对J类指令，标签是否存在
###############################################

#处理文件
def process_file(infile,outfile):
    with open(infile,'r',encoding='utf-8') as infile:
        instructions=infile.readlines()
    #两次扫描，生成机器码
    pocessed_instructions, label2adder, labels, instructions_line  = first_scan(instructions)
    machine_code = second_scan(pocessed_instructions, label2adder, labels, instructions_line)
    
    with open(outfile,'w') as outfile:
        outfile.write(f';This .COE file specifies the content for a block memory of depth={len(machine_code)}, and width=32\n')
        outfile.write(f'memory_initialization_radix={len(machine_code)};\n')
        outfile.write('memory_initialization_vector=\n')
        for i, line in enumerate(machine_code[0:-1]):
            line =  hex(int(line, 2))[2:].zfill(8).upper()
            outfile.write(line+','+'\n')
        line = machine_code[len(machine_code) - 1]
        line =  hex(int(line, 2))[2:].zfill(8).upper()
        outfile.write(line + ';')

    return 

#处理单行生成机器码
def pocess_line(op,param,row,label2addr,address):
    func = functions.get(op, "error")
    if func == "error":
        raise Exception('Line %d : No such operator.' % row)
    hexcodestr = func(param, row, label2addr, address)
    return hexcodestr

def check_error(op, param, labels, line):
    #if line == 42:
    instructions_with_labels = ['bltz', 'blez', 'j', 'jal', 'beq', 'bne']
    R_instructions = ['sll', 'srl', 'sra', 'add', 'sub', 'and', 'or', 'xor', 'nor', 'slt']
    imm_instructions = ['addi', 'slti', 'andi','ori', 'xori', 'lui']
 
    if op not in functions.keys():
        print("line %d: No such instruction"%(line))
        return False
 
    if op in R_instructions:
        for i in range(len(param)):
            try:
                param[i] = int(param[i])
                if op in ['sll', 'srl', 'sra'] and i == 2:
                    if param[i] > 31 or param[i] < -32:
                        print("line %d: The shamt out of limit" %(line))
                        return False
                    break
                print("line %d: The R_instructions don't accept imm" %(line))
                return False
            except:
                pass
 
    if op in imm_instructions:
        if op == 'lui':
            imm = param[1]
        else: imm = param[2]
        
        try:
            imm = int(imm)
        except:
            print("line %d: require imm" %(line))
            return False
        if imm > 32767 or imm<-32768:
            print("line %d: the imm out of limit" %(line))
            return False
 
    if op in instructions_with_labels:
        if op in ['blez', 'bltz']:
            label = param[1]
        elif op in ['j', 'jal']:
            label = param[0]
        else: label = param[2]
 
        if label not in labels.keys():
            print("line %d: no such label" %(line))
            return False
 
    if op in ['jr', 'jalr']:
        rs = param[0]
        if rs not in register:
            print("line %d: no such register" %(line))
            return False
    return True

#扫描第一遍，分配指令地址，寻找符号，即标号和全局变量
def first_scan(instructions):
    labels = {}
    label2addr = {}
    pocessed_instructions = []
    instructions_line = []
    addr = 0
    for i in range(len(instructions)):
        #处理空行
        instructions[i] = instructions[i].strip()
        if instructions[i] == '':
            continue
        #处理注释
        if re.search('#', instructions[i]):                 
            pos = re.search('#', instructions[i]).span()[0]
            if instructions[i][0: pos].strip() == '':
                continue
            instructions[i] = instructions[i][0: pos]
        #单独处理标签行
        if re.search(':', instructions[i]):
            pos = re.search(':', instructions[i]).span()[0]
            label_name = instructions[i][0: pos].strip()
            label2addr[label_name] = addr
            labels[label_name] = i
            continue
        #初步处理好指令（暂时没有进行错误指令的判断和删除,后面生成代码的时候再删除应该也可以吧（？））
        pocessed_instructions.append(instructions[i])
        # 记录指令的行数
        instructions_line.append(i+1)
        #地址增加
        addr += 4 
    return pocessed_instructions, label2addr, labels, instructions_line


#扫描第二遍，产生机器码，保存机器代码和符号表
def second_scan(pocessed_instructions,labels,label2addr, instructions_line):
    machine_code=[]
    address = 0
    for i in range(len(pocessed_instructions)):
        #标准化指令格式
        param = pocessed_instructions[i].split(' ')
        for j in range(len(param)):
            param[j]=param[j].strip(',')
            param[j]=param[j].strip('\t')
            
            #处理括号里有立即数的情况
            if re.search("[(]",param[j]):
                pos = re.search("[(]",param[j]).span()[0]
                param.append(param[j][pos+1:-1])
                param[j] = param[j][0:pos]
           
            #其他进制的立即数转化为十进制
            try:
                if param[j] != 'j':
                    param[j] = eval(param[j])
            except:
                    pass
            
        for k in range(len(param)-1,-1,-1):
            if param[k] == '':
                del param[k]

        op  = param[0]
        del param[0]

        #生成并分配指令地址
        if check_error(op, param, labels, instructions_line[i]) == True:
            machine_code.append(pocess_line(op, param, instructions_line[i], label2addr, address))
            address += 4
        else:
            continue
    return machine_code

process_file('mips.asm', 'outfile.coe')
